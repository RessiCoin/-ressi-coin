# Security Policy

## Official contract

The only contract address identified by this project is:

`0x06af1719093e3a745acf9db95b21537e7c93b763`

Network: Base

Verify the entire address on BaseScan before trading or connecting a wallet. The project will never ask users to share seed phrases, private keys, or wallet recovery codes.

## Reporting concerns

Until a dedicated security email is published, report suspected impersonation or fraudulent links through the verified project's official social profile. Do not post sensitive vulnerability details publicly.

## Audit status

No independent security audit is claimed in this repository. RESSI was created through Zora; users should independently review the on-chain contract and Zora protocol documentation.

