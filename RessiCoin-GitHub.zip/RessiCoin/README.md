# RESSI

**The fastest bird on-chain. Built for speed. Born to run. Welcome to the Fast Lane.**

RESSI is a community-focused creator coin deployed on Base through Zora. This repository is the official public source for the project's verified contract information, disclosures, roadmap, and community resources.

## Verified asset information

| Field | Value |
|---|---|
| Asset name | RESSI |
| Symbol | RESSI |
| Network | Base |
| Token standard | ERC-20 |
| Contract address | `0x06af1719093e3a745acf9db95b21537e7c93b763` |
| Official trading page | [Zora](https://zora.co/coin/base:0x06af1719093e3a745acf9db95b21537e7c93b763) |
| Block explorer | [BaseScan](https://basescan.org/token/0x06af1719093e3a745acf9db95b21537e7c93b763) |

Always verify the complete contract address before interacting with the asset. RESSI has not authorized any alternate contract address.

## Project purpose

RESSI is an entertainment and community-oriented meme/creator coin. The project uses original character-led content and social storytelling to build an on-chain community around speed, confidence, and the “Fast Lane” identity.

RESSI does not represent equity, ownership, debt, profit-sharing rights, or a promise of financial return.

## Documentation

- [Token information and disclosures](docs/TOKEN_INFORMATION.md)
- [Project roadmap](ROADMAP.md)
- [Security policy](SECURITY.md)
- [Risk disclaimer](DISCLAIMER.md)

## Official links

Official website and social channels will be added here after they are verified by the project owner. Do not rely on unofficial links posted by third parties.

## Contact

Official project contact information will be published here after verification.

## Status

This repository documents an existing token deployed through Zora. It does not contain a separately deployed token contract. Contract mechanics and authoritative on-chain activity should be verified through BaseScan and the official Zora page.

